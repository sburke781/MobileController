library (
 author: "Simon Burke",
 category: "logging",
 description: "Logging preference settings",
 name: "logging",
 namespace: "simnet",
 documentationLink: ""
)

preferences {
// Logging Preferences
input(name: "DebugLogging", type: "bool", title:"Enable Debug Logging", description:"Debug Logging will automatically turn off after 30 minutes", displayDuringSetup: true, defaultValue: false)
input(name: "WarnLogging",  type: "bool", title:"Enable Warning Logging",                                                                         displayDuringSetup: true, defaultValue: true )
input(name: "ErrorLogging", type: "bool", title:"Enable Error Logging",                                                                           displayDuringSetup: true, defaultValue: true )
input(name: "InfoLogging",  type: "bool", title:"Enable Description Text (Info) Logging",                                                         displayDuringSetup: true, defaultValue: false)
}

//Logging Utility methods
void debugLog(debugMessage) {
	if (DebugLogging == true) {log.debug(debugMessage)}	
}

void errorLog(errorMessage) {
    if (ErrorLogging == true) { log.error(errorMessage)}  
}

void infoLog(infoMessage) {
    if(InfoLogging == true) {log.info(infoMessage)}    
}

void warnLog(warnMessage) {
    if(WarnLogging == true) {log.warn(warnMessage)}    
}

void debugOff() {

   log.warn("Disabling debug logging");
   device.updateSetting("DebugLogging", [value:"false", type:"bool"])
}

void updated_debugTimout() {
    if (DebugLogging) {
     log.debug "updated: Debug logging has been turned on and will be automatically disabled in ${debugAutoDisableMinutes} minutes"
     runIn(debugAutoDisableMinutes*60, "debugOff")
   }
   else { unschedule("debugOff") }
}

import groovy.json.JsonOutput;
import groovy.transform.Field

@Field static final Integer debugAutoDisableMinutes = 30